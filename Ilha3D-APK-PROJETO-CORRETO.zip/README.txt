Projeto Android Ilha 3D
O jogo original foi incluído sem alterações em:
app/src/main/assets/index.html

Este ZIP contém o projeto Android. Para compilar no GitHub Actions,
o arquivo ZIP deve ficar na raiz do repositório e o workflow deve ficar
separadamente em .github/workflows/build.yml.
